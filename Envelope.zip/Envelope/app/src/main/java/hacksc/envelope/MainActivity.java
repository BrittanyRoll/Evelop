package hacksc.envelope;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private TextView mTextMessage;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_dashboard:
                    mTextMessage.setText(R.string.title_dashboard);
                    return true;
                case R.id.navigation_notifications:
                    mTextMessage.setText(R.string.title_notifications);
                    return true;
            }
            return false;
        }
    };

    /*
    public class User {
        public String email;
        public String name;
        public String password;
        public Double goals_savings;

        User(String e, String n, String p, Double gs) {
            email = e;
            name = n;
            password = p;
            goals_savings = gs;
        }
    }
    */

    /*
    final FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference ref = database.getReference("server/saving-data/fireblog");

    DatabaseReference usersRef = ref.child("users");
    */

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("users");


    Map<String, Users> users; //will put into  database



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        mTextMessage = findViewById(R.id.message);
        navView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        //testing





        //button stuff
        Button button = findViewById(R.id.submit);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //get user input

                EditText edit = (EditText)findViewById(R.id.gettingemail);
                String em = edit.getText().toString();

                EditText edit2 = findViewById(R.id.gettingname);
                String nam = edit2.getText().toString();
                EditText edit3 = findViewById(R.id.gettingpassword);
                String pass = edit3.getText().toString();

                EditText edit4 = findViewById(R.id.gettinggoal);
                Double goal = Double.parseDouble(edit4.getText().toString());


                  /*
                String em = "b";

                String nam = "hi";
                String pass = "hi";
                Double goal = 2000.0;

                Users hi = new Users(em, nam, pass, goal);
                String em2 = "j";
                Users hi2 = new Users(em2, nam, pass, goal);
                myRef.child(em).setValue(hi);
                myRef.child(em2).setValue(hi2);
                */
                Users new_user = new Users(em, nam, pass, goal);
                myRef.child(em).setValue(new_user);
                myRef.orderByKey();
                System.out.println(myRef.child("users").child("b"));
                String find = "b";

            }
        });



    }

}
