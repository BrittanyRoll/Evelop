package hacksc.envelope;

public class Users {
        public String email;
        public String name;
        public String password;
        public Double goals_savings;

        Users(String e, String n, String p, Double gs) {
            email = e;
            name = n;
            password = p;
            goals_savings = gs;
        }
}
